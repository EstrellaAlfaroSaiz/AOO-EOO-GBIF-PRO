# LRN/GBIF

Plugin QGIS para descarga y filtrado de ocurrencias GBIF, adición/revisión de puntos propios, cálculo de AOO/EOO y generación de Point Distribution CSV compatible con SRedList.

## Funciones principales

- Descarga ocurrencias de GBIF con filtros metodológicos.
- Permite añadir puntos propios haciendo clic en el mapa, por coordenadas o mediante CSV.
- Permite eliminar puntos propios haciendo clic cerca del punto.
- Permite seleccionar una o varias capas de puntos para calcular AOO y EOO.
- Calcula AOO mediante cuadrícula, por defecto 2 x 2 km.
- Calcula EOO mediante convex hull.
- Genera capas AOO/EOO con atributos IUCN obligatorios/condicionales.
- Genera Point Distribution CSV con el esquema de 21 campos solicitado.
- Permite solicitar a GBIF una descarga oficial por gbifID usados para obtener DOI.
- Añade una evaluación preliminar de Criterio B IUCN basada en AOO, EOO y subcriterios indicados por la persona evaluadora.

## Nota metodológica

La evaluación IUCN Criterion B incluida es preliminar. AOO y EOO por sí solos no asignan categoría: se necesitan además los subcriterios B(a), B(b) y B(c), introducidos en la pestaña de cálculo.

Autoría: Alfaro-Saiz Estrella.
Créditos: Grupo de Especialistas de Especies IUCN España.


## Cambios v1.2.0

- Selección múltiple real de capas de puntos en la pestaña 3.
- Botones para actualizar, marcar capa activa, marcar todas y desmarcar todas.
- El cálculo usa solo las capas marcadas.
- El informe muestra una categoría orientativa según los umbrales de AOO y EOO.


## v1.12

- Añade importación de capas vectoriales de puntos desde shapefile/GeoPackage/GeoJSON. La capa importada se añade al proyecto y queda marcada para el cálculo en la pestaña 3.


## v1.12

- Corrige la exportación de Point Distribution a shapefile cuando `event_year` está vacío. Los campos numéricos opcionales vacíos se escriben como NULL, no como cadena vacía.


## v1.13
- Al pulsar Enter en el campo de nombre científico se resuelve el taxonKey.
- Se evita que Enter active accidentalmente botones auxiliares como “Ver criterios del filtro”.
